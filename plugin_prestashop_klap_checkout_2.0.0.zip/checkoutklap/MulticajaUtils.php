<?php

class MulticajaUtils {

  public static function getFullVersionPrestashop() {
    return _PS_VERSION_;
  }

  public static function getBaseVersionPrestashop() {
    return substr(_PS_VERSION_, 0, 3);
  }

  public static function isPrestashop_1_6() {
    return self::getBaseVersionPrestashop() == '1.6';
  }

  public static function isPrestashop_1_7() {
    return self::getBaseVersionPrestashop() == '1.7';
  }

  public static function startsWith($string, $startString) {
    $len = strlen($startString);
    return (substr($string, 0, $len) === $startString);
  }
}
