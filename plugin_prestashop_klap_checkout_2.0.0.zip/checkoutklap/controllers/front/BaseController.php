<?php
if (!defined('_PS_VERSION_')) {
  exit;
}

// carga el sdk de multicaja pasarela
require_once(_PS_MODULE_DIR_ . 'checkoutklap/sdk/src/init.php');

require_once(_PS_MODULE_DIR_ . 'checkoutklap/HelperPasarela.php');
require_once(_PS_MODULE_DIR_ . 'checkoutklap/MulticajaUtils.php');

use \Multicaja\Payments\Model\AmountDetails;
use \Multicaja\Payments\Model\Amount;
use \Multicaja\Payments\Model\User;
use \Multicaja\Payments\Model\Item;
use \Multicaja\Payments\Model\Custom;
use \Multicaja\Payments\Model\Urls;
use \Multicaja\Payments\Model\Webhooks;
use \Multicaja\Payments\Model\Method;
use \Multicaja\Payments\Model\Error;
use \Multicaja\Payments\Model\OrderRequest;
use \Multicaja\Payments\Model\OrderResponse;
use \Multicaja\Payments\Utils\PaymentsApiClient;
use \Multicaja\Payments\Utils\ValidateParams;

class BaseController extends ModuleFrontController {

  protected $hp;
  protected $logger;
  const VALUE = 'value';
  const TARJETAS = 'tarjetas';
  const SODEXO = 'sodexo';
  const EFECTIVO_TRANSFERENCIA = 'efectivo_transferencia';

  public function getEcommerceData() {
    return array(
      'pluginVersion' => MCP_PLUGIN_VERSION,
      'ecommerceInfo' => 'prestashop-' . _PS_VERSION_,
      'webhooksBaseUrl' => Context::getContext()->link->getModuleLink('checkoutklap', 'CallbackHandler'),
      'orderStatusPendingPayment' => Configuration::get('PS_OS_BANKWIRE'),
      'orderStatusPaid' => Configuration::get('PS_OS_PAYMENT'),
      'orderStatusFailed' => Configuration::get('PS_OS_ERROR')
    );
  }

  public function getConfigValue($key, $defaultValue) {
    $value = Configuration::get($key, $defaultValue);
    return $value == '' || $value == null ? $defaultValue : $value;
  }

  /**
   * Metodo por defecto a implementar en los controladores de Prestashop
   */
  public function initContent() {
    $this->ssl = true;
    $this->display_column_left = false;
    $this->hp = new HelperPasarela($this, 'MCP_');
    $this->logger = $this->hp->getLogger();
    parent::initContent(); //es necesario llamar al initContent del padre
  }

  /**
   * Agrega un metadato a la orden
   */
  protected function addMetadataToOrder($referenceId, $orderEcommerce, $key, $value) {
    $message = $key . '=' . $value;
    $msg = new Message();
    $msg->message = strip_tags($message, '<br>');
    $msg->id_cart = (int) $referenceId;
    $msg->id_customer = (int) ($orderEcommerce->id_customer);
    $msg->id_order = (int) $orderEcommerce->id;
    $msg->private = 1;
    $msg->add();
  }

  /**
   * Retorna la fecha formateada con zona horaria
   */
  protected function getCurrentDateTime() {
    date_default_timezone_set('America/Santiago');
    return date('F j, Y, G:i:s') . ' ' . date_default_timezone_get();
  }

   /**
   * crea la orden en checkout KLAP
   */
  public function createOrder($cart, $method) {
    $referenceId = $cart->id;
    try {
      $this->logger->info('Creando orden metodo de pago: '.  $method);
      $customer = new Customer($cart->id_customer);

      $returnUrl = $this->hp->getReturnUrl().'&referenceId='.$referenceId;
      $cancelUrl = $this->hp->getCancelUrl().'&referenceId='.$referenceId;
      $logoUrl = $this->hp->getLogoUrl();
      $webhookConfirm = $this->hp->getWebhookConfirm();
      $webhookReject = $this->hp->getWebhookReject();
      $runtimeInfo = $this->hp->getRuntimeInfo();
      $ecommerceInfo = $this->hp->getEcommerceInfo();
      $description = null;
      $amount = intval(round(number_format($cart->getOrderTotal(true, Cart::BOTH), 0, ',', '')));
      $summary = $cart->getSummaryDetails();

      $orderRequest = new OrderRequest();

      //agrega los items del carro a los items de la orden
      $cartItems = $cart->getProducts(true);
      foreach ($cartItems as $cartItem) {
        $name = strval($cartItem['name']);
        $code = strval($cartItem['id_product']);
        $quantity = intval($cartItem['cart_quantity']);
        $unitPrice = intval(round($cartItem['price_wt']));
        $price = $unitPrice * $quantity;
        $orderRequest->addItem(new Item($name, $code, $price, $unitPrice, $quantity));
        $description = $name;
      }

      //agrega el costo de envio a los items de la orden
      $shippingPrice = intval(round($summary['total_shipping']));
      if ($shippingPrice != 0) {
        $name = 'Costo por envio';
        $code = 'Envio';
        $quantity = 1;
        $price = $shippingPrice;
        $orderRequest->addItem(new Item($name, $code, $price, $price, $quantity));
      }

      if ($description == null) {
        $description = 'Compra de varios productos';
      }

      //si el valor de logo_url no es una url se reescribe en null para evitar error en pasarela
      if (filter_var($logoUrl, FILTER_VALIDATE_URL) === FALSE) {
        $logoUrl = null;
      }
      $address = new Address($this->context->cart->id_address_invoice);
      $addressString = $address->address1;
      if (!empty($address->address2)) {
        $addressString = $addressString . ', ' . $address->address2;
      }

      if($amount < 50) {
          throw new \InvalidArgumentException('¡El monto de la compra debe ser de por lo menos $50!');
      }

      if(!empty($customer->email)) {
        $is_correct = preg_match('/^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$/', $customer->email);
        if (!$is_correct) {
          throw new \InvalidArgumentException('¡Email inválido! Debes ingresar email válido! ej. prueba@prueba.cl');
        }
      }

      $user["rut"] = null;
      $user["email"] = $customer->email;
      $user["first_name"] = $customer->firstname;
      $user["last_name"] = $customer->lastname;
      $user["phone"] = null;
      $user["address_line"] = $addressString;
      $user["address_city"] = $address->city;
      $user["address_state"] = $address->city;
      $orderRequest->setUser(new User($user));
      $orderRequest->setReferenceId((string)$referenceId);
      $orderRequest->setDescription($description);
      $orderRequest->setAmount(new Amount('CLP', $amount));
      $orderRequest->addCustom(array('key' => 'internal_plugin_version', self::VALUE => MCP_PLUGIN_VERSION));
      $orderRequest->addCustom(array('key' => 'internal_ecommerce_runtime', self::VALUE => $runtimeInfo));
      $orderRequest->addCustom(array('key' => 'internal_ecommerce_name', self::VALUE => $ecommerceInfo));
      $orderRequest->addCustom(array('key' => 'payments_notify_user', self::VALUE => $this->hp->getPaymentsNotifyUser()));
      if ($method === self::TARJETAS) {
        $orderRequest->setMethods(array('tarjetas'));
        $orderRequest->addCustom(array('key' => 'tarjetas_expiration_minutes', self::VALUE => $this->hp->getTarjetasExpirationMinutes()));
      } else if ($method === self::EFECTIVO_TRANSFERENCIA) {
        $orderRequest->setMethods(array('efectivo', 'transferencia'));
        $orderRequest->addCustom(array('key' => 'efectivo_expiration_minutes', self::VALUE => $this->hp->getEfectivoExpirationMinutes()));
        $orderRequest->addCustom(array('key' => 'transferencia_expiration_minutes', self::VALUE => $this->hp->getTransferenciaExpirationMinutes()));
      } else if ($method === self::SODEXO) {
        $orderRequest->setMethods(array('sodexo'));
        $orderRequest->addCustom(array('key' => 'sodexo_expiration_minutes', self::VALUE => $this->hp->getSodexoExpirationMinutes()));
      }
      $orderRequest->setUrls(new Urls($returnUrl, $cancelUrl, $logoUrl));
      $orderRequest->setWebhooks(new Webhooks(null, $webhookConfirm, $webhookReject));

      //crea la orden en multicaja
      try {
        $environment = $this->hp->getEnvironment();
        $apikey = $this->hp->getApiKey();
        PaymentsApiClient::setLogger($this->logger);
        $response = PaymentsApiClient::createOrder($environment, $apikey, $orderRequest);
      } catch (Exception $ex) {
        $this->logger->error('Error al crear la orden: ' . $ex->getMessage());
        $response = new Error('0', 'Error al crear la orden');
      }

      if ($response == null) {
        throw new InvalidArgumentException('Error al intentar conectar con Klap Checkout, sin respuesta. Por favor intenta más tarde.');
      }

      if (!($response instanceof OrderResponse)) {
        $this->logger->error(json_encode($response));
        throw new InvalidArgumentException('Error en la respuesta de  Klap Checkout. Por favor intenta más tarde.');
      }

      if ($response->getRedirectUrl() == null) {
        throw new InvalidArgumentException('Error al intentar conectar con  Klap Checkout. Por favor intenta más tarde.');
      }

      $purchaseDate = $this->getCurrentDateTime();

      $this->logger->info('Orden creada con exito usando [Klap Checkout] en espera del pago, referenceId: ' . $referenceId . ', orderId: ' . $response->getOrderId() . ', fecha: ' . $purchaseDate);

      if (MulticajaUtils::isPrestashop_1_6()) {
        $this->setTemplate('payment_redirect_1.6.tpl');
      } else {
        $this->setTemplate('module:checkoutklap/views/templates/front/payment_redirect.tpl');
      }
      Tools::redirect($response->getRedirectUrl());
    } catch (Exception $ex) {

      $this->logger->error('order: ' . $referenceId . ', error: ' . $ex->getMessage(), $ex);

      $this->context->smarty->assign(array(
        'referenceId' => $referenceId,
        'message' => $ex->getMessage()
      ));

      if (MulticajaUtils::isPrestashop_1_6()) {
        $this->setTemplate('payment_error_1.6.tpl');
      } else {
        $this->setTemplate('module:checkoutklap/views/templates/front/payment_error.tpl');
      }
    }
  }
}
