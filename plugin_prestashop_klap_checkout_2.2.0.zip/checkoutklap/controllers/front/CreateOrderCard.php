<?php

require_once(__DIR__.'/BaseController.php');

use \Multicaja\Payments\Model\AmountDetails;
use \Multicaja\Payments\Model\Amount;
use \Multicaja\Payments\Model\User;
use \Multicaja\Payments\Model\Item;
use \Multicaja\Payments\Model\Custom;
use \Multicaja\Payments\Model\Urls;
use \Multicaja\Payments\Model\Webhooks;
use \Multicaja\Payments\Model\Method;
use \Multicaja\Payments\Model\Error;
use \Multicaja\Payments\Model\OrderRequest;
use \Multicaja\Payments\Model\OrderResponse;
use \Multicaja\Payments\Utils\PaymentsApiClient;
use \Multicaja\Payments\Utils\ValidateParams;

class CheckoutKlapCreateOrderCardModuleFrontController extends BaseController {

  /**
   * Metodo por defecto a implementar en los controladores de Prestashop
   */
  public function initContent() {
    parent::initContent(); //es necesario llamar al initContent del padre
    $cart = $this->context->cart;
    parent::createOrder($cart, self::TARJETAS);
  }
}
